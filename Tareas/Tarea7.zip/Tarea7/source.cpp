#include "tarea7.h"
int main() {
    setlocale(LC_ALL, "");
    menu();
    return 0;
}
