#include "Ejercicio7.h"
int main() {
    menu();
    return 0;
}
