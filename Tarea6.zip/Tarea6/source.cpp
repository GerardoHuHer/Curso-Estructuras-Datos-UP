#include "tarea6.h"
int main() {
    menu(); 
    return 0;
}
