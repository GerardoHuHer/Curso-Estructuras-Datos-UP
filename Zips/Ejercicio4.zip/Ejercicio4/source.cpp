#include "Ejercicio4.h"
int main() {
    menu();
    return 0;
}
