#include "ejercicio9.h"
int main() {
    ColaCirular C;
    C.mostrar();
    C.insertar("AA");
    C.insertar("BB");
    C.insertar("CC");
    C.mostrar();
    C.extraer();
    C.mostrar();
    C.insertar("DD");
    C.insertar("EE");
    C.insertar("FF");
    C.mostrar();
    C.insertar("GG");
    C.insertar("HH");
    C.mostrar();
    C.extraer();
    C.extraer();
    C.mostrar();
    return 0;
}
