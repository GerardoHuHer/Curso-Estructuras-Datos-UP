#include "Tarea4A.h"
int main() {
    menu();
    return 0;
}
