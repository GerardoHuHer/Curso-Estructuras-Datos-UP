#include "Tarea3.h"
int main() {
    Array obj = Array();
    menu(obj);
    return 0;
}
