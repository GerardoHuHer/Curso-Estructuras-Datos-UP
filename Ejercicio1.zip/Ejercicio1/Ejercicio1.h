#pragma once
#include <iostream>
/*Empleando C++, construye una aplicación Orientada a Objetos, que permita realizar dos tareas:
a) Recibir repetidamente números enteros y los vaya sumando, hasta que reciba un cero. En este momento debe informar cuántos números recibió y la suma de ellos.
b) Leer exactamente 9 números enteros y al finalizar debe informar cuántos de ellos son pares y cuanto suman. Informar también cuántos son impares y cuánto suman.*/

class Ejercicio{
public:
  void ejercicio_a();
  void ejercicio_b();
};
