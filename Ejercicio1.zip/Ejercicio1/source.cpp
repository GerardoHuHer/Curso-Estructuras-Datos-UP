#include "Ejercicio1.h"
int main() {
    Ejercicio obj = Ejercicio();
    obj.ejercicio_a();
    obj.ejercicio_b();
    return 0;
}
