#include "Tarea2Registros.h"
int main() {
    menu();
    return 0;
}
