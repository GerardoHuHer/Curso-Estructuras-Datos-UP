#include "Ejercicio3.h"
#include <clocale>
int main() {
    setlocale(LC_ALL, "");
    menu();
    return 0;
}
